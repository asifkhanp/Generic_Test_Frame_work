"""
Author : Asif Khan M Pathan
Test Automation Framework
"""

class Device:
    """
    Abstract Device Class
    """
    # """
    # Device Module
    # """
    # def __init__(self):
    #     #print("Device Class")
    #     self.dut = None
    #     self.transport = None
    #
    # def create_device_and_transport(self, **kwargs):
    #     """
    #     create the device and transport instance
    #     :param kwargs: will be updated later
    #     :return: None
    #     """
    #     print(f"parrent Device create_device_and_transport {kwargs}")
    #
    # def dummy(self):
    #     """
    #     dummy function for pylint
    #     :return: None
    #     """
    #     return None


if __name__ == "__init__":
    print("Executing the Device Class")
